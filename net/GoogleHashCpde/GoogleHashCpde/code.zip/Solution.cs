﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GoogleHashCpde.Object;
using static System.String;

namespace GoogleHashCpde
{
    class Solution
    {
        public Dictionary<Cache, ISet<Video>> Results { get; private set; }

        public Solution()
        {
            Results = new Dictionary<Cache, ISet<Video>>();
        }

        public void WriteToFile(string file)
        {
            var content = new string[Results.Count+1];
            content[0] = Results.Count.ToString();
            var vCache = Results.Select(s =>
            {
                var val = Join(" ", s.Value.Select(v => v.Id.ToString()).ToList());
                return $"{s.Key.Id} {val}";
            }).ToArray();
            Array.Copy(vCache, 0, content, 1, vCache.Length);
            File.WriteAllLines(file, content);
        }

        public int Evaluate()
        {
            return 0;
        }

        public void PutVideoInCache(Cache cache, Video v)
        {
            ISet<Video> videos;
            if (!Results.TryGetValue(cache, out videos))
            {
                videos = new HashSet<Video>();
                Results.Add(cache,videos);
            }
            videos.Add(v);
        }
    }
}
