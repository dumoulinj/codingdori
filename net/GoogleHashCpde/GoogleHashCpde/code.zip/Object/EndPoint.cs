﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace GoogleHashCpde.Object
{
    class EndPoint
    {
        public int Id { get; private set; }
        public int Latency { get; private set; }
        public EndPointCacheLatency[] CacheIds { get; private set; }

        public EndPoint(int id, int latency, EndPointCacheLatency[] cacheIds)
        {
            Id = id;
            Latency = latency;
            CacheIds = cacheIds;
        }
    }

    class EndPointCacheLatency
    {
        public Cache Cache { get; private set; }
        public int Latency { get; private set; }

        public EndPointCacheLatency(Cache cache, int latency)
        {
            Cache = cache;
            Latency = latency;
        }
    }

    class Cache
    {
        public int Id { get; private set; }
        public int Size { get; private set; }

        public Cache(int id, int size)
        {
            Id = id;
            Size = size;
        }

        protected bool Equals(Cache other)
        {
            return Id == other.Id;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((Cache) obj);
        }

        public override int GetHashCode()
        {
            return Id;
        }
    }

    class Request
    {
        public Video Video { get; private set; }
        public EndPoint EndPoint { get; private set; }
        public int Number { get; private set; }

        public Request(Video video, EndPoint endPoint, int number)
        {
            Video = video;
            EndPoint = endPoint;
            Number = number;
        }
    }
}
